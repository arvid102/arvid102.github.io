/**
 * Scene objects.
 */

//=include geometry/ground.js
//=include geometry/dyno.js
//=include geometry/dyno_band.js
//=include geometry/cactus.js
//=include geometry/ptero.js

//=include geometry/rocks.js
//=include geometry/flowers.js
//=include geometry/misc.js

// load_manager.azaza(function() {
	
// });